/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LIBRERIA;

/**
 *
 * @author erick
 */
public class funciones {
    public double areaT(double a, double b){
        return((b*a)/2);
    }
    public int perimetroC(int a, int b){
        return (a*4);
    }
    public int areaCuadrado(int a){
        return (a*a);
    }
}
